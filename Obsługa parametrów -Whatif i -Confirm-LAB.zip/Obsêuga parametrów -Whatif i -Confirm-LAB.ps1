﻿
function Get-LabComputerSystem {
    <#
    .Synopsis
    Krótki opis
    .DESCRIPTION
    Długi opis
    .PARAMETER ComputerName
    To jest opis ComputerName
    .EXAMPLE
    Get-LabComputerSystem -ParamName "V1" -Verbose
    Opis przypadku użycia.
    .EXAMPLE
    Get-LabComputerSystem  -ParamName "V1", "V2", "V3" -Verbose #rozwiązany
    Opis przypadku użycia.
    .EXAMPLE
    "BBB", "CCC" | Get-LabComputerSystem -Verbose
    Opis przypadku użycia.
    .OUTPUTS
    Zwraca info tylko w kanale "Verbose"
     #>
    [CmdletBinding()]
    Param(
        [Parameter(Mandatory = $True,
            ValueFromPipeline = $True,
            ValueFromPipelineByPropertyName = $True)]
        [ValidatePattern("^PSA-\w{2,3}\d{1,2}$")]
        [string[]]$ComputerName
    )
    PROCESS {
        foreach ($Computer in $ComputerName) {
            Write-Verbose "Now connecting to: $Computer"
            $compsys = Get-CimInstance -ClassName Win32_ComputerSystem -ComputerName $Computer
            $bios = Get-CimInstance -ClassName Win32_BIOS -ComputerName $computer
            $properties = [ordered]@{
                'ComputerName' = $Computer;
                'BIOSSerial'   = $bios.serialnumber;
                'Manufacturer' = $compsys.Manufacturer;
                'Model'        = $compsys.Model
            }
            $output = New-Object -TypeName PSObject -Property $properties
            Write-Output $output
        }
    }
}
function Set-LabComputerSystem {
    <#
.Synopsis
    Krótki opis
.DESCRIPTION
    Długi opis
.PARAMETER ComputerName
    To jest opis ComputerName
.PARAMETER State
    To jest opis State
.PARAMETER force
    To jest opis force
.EXAMPLE
    Set-LabComputerSystem -ComputerName PSA-DC1 -State Restart -force
    Opis przypadku użycia.
.EXAMPLE
    Set-LabComputerSystem  -ParamName "V1", "V2", "V3" -Verbose #rozwiązany
    Opis przypadku użycia.
.EXAMPLE
    "BBB", "CCC" | Set-LabComputerSystem -Verbose
    Opis przypadku użycia.
.OUTPUTS
    Zwraca info tylko w kanale "Verbose"
#>
    [CmdletBinding(SupportsShouldProcess = $True, ConfirmImpact = "Medium")]
    param(
        [Parameter(
            Mandatory = $True,
            ValueFromPipeline = $True,
            ValueFromPipelineByPropertyName = $True)]
        [ValidatePattern("^PSA-\w{2,3}\d{1,2}$")]
        [string[]]$ComputerName,

        [Parameter(Mandatory = $True)]
        [ValidateSet('PowerOff', 'Shutdown', 'Restart', 'Logoff')]
        [string]$State,

        [switch]$Force
    )
    BEGIN {
        switch ($State) {
            'LogOff' {
                $_action = 0
            }
            'Shutdown' {
                $_action = 1
            }
            'Restart' {
                $_action = 2
            }
            'PowerOff' {
                $_action = 8
            }
        }
        if ($PSBoundParameters.ContainsKey('force')) {
            $_action += 4
        }
        Write-Verbose "Action value is $_action"
    }
    PROCESS {
        foreach ($computer in $ComputerName) {
            if ($PSCmdlet.ShouldProcess("$Computer - action is $_action")) {
                Write-Verbose "Contacting $Computer"
                $os = Get-WmiObject -Class Win32_OperatingSystem -ComputerName $Computer -EnableAllPrivileges
                $os.win32shutdown($_action)
            }
        }
    }
}

Import-Module -Name MyLabModule -Force

Set-LabComputerSystem -ComputerName PSA-SVR1 -State Restart
# jeśli nie działa to na SVR blokuje go firewall
# Enable-NetFirewallRule -DisplayGroup "Windows Management Instrumentation (WMI)"
#endregion - 02-08-Obsługa parametrów -Whatif i -Confirm-LAB.ps1