﻿
#region - 05-01-Windows Forms-LAB.ps1

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$form = New-Object System.Windows.Forms.Form
$form.Text = 'Data Entry Form'
$form.Size = New-Object System.Drawing.Size(300, 250)
$form.StartPosition = 'CenterScreen'

$OKButton = New-Object System.Windows.Forms.Button
$OKButton.Location = New-Object System.Drawing.Point(25, 170)
$OKButton.Size = New-Object System.Drawing.Size(75, 23)
$OKButton.Text = 'OK'
$OKButton.DialogResult = [System.Windows.Forms.DialogResult]::OK
$form.AcceptButton = $OKButton
$form.Controls.Add($OKButton)

$CancelButton = New-Object System.Windows.Forms.Button
$CancelButton.Location = New-Object System.Drawing.Point(100, 170)
$CancelButton.Size = New-Object System.Drawing.Size(75, 23)
$CancelButton.Text = 'Cancel'
$CancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.CancelButton = $CancelButton
$form.Controls.Add($CancelButton)

$DisableButton = New-Object System.Windows.Forms.Button
$DisableButton.Location = New-Object System.Drawing.Point(175, 170)
$DisableButton.Size = New-Object System.Drawing.Size(75, 23)
$DisableButton.Text = 'Disable'
$DisableButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel
$form.Controls.Add($DisableButton)

$label = New-Object System.Windows.Forms.Label
$label.Location = New-Object System.Drawing.Point(10, 20)
$label.Size = New-Object System.Drawing.Size(280, 20)
$label.Text = 'Please make a selection from the list below:'
$form.Controls.Add($label)

$listBox = New-Object System.Windows.Forms.Listbox
$listBox.Location = New-Object System.Drawing.Point(10, 40)
$listBox.Size = New-Object System.Drawing.Size(260, 70)
$listBox.SelectionMode = 'MultiExtended'  #  None, One, MultiSimple, MultiExtended

$LPasswd = New-Object system.Windows.Forms.Label
$LPasswd.text = "new password"
$LPasswd.AutoSize = $true
$LPasswd.width = 25
$LPasswd.height = 10
$LPasswd.location = New-Object System.Drawing.Point(10, 120)
$LPasswd.Font = 'Microsoft Sans Serif,10'

$TBPasswd = New-Object system.Windows.Forms.TextBox
$TBPasswd.multiline = $false
$TBPasswd.width = 150
$TBPasswd.height = 20
$TBPasswd.location = New-Object System.Drawing.Point(120, 120)
$TBPasswd.Font = 'Microsoft Sans Serif,10'
$TBPasswd.PasswordChar = '*'

$ADUsers = Get-ADUser -Filter * -SearchBase "OU=DEMO,DC=Contoso,DC=com"
foreach ($ADUser in $ADUsers) {
    [void] $listBox.Items.Add("$($ADUser.SamAccountName)")
}

$form.Controls.AddRange(@($listBox, $LPasswd, $TBPasswd))
$form.Topmost = $true

$OKButton.Add_Click( {
        $SelectedUsers = $listBox.SelectedItems
        $pass = $TBPasswd.Text | ConvertTo-SecureString -AsPlainText -Force
        foreach ($SelectedUser in $SelectedUsers) {
            Write-Host "Reset password: $SelectedUser"
            Set-ADAccountPassword -Identity $SelectedUser -NewPassword  $pass
        }
    })

$DisableButton.Add_Click( {
        $SelectedUsers = $listBox.SelectedItems
        foreach ($SelectedUser in $SelectedUsers) {
            Write-Host "Disabled account: $SelectedUser" -ForegroundColor Cyan
            Disable-ADAccount -Identity $SelectedUser
        }
    })

[void]$Form.ShowDialog()
#endregion - 05-01-Windows Forms-LAB.ps1