﻿#region - 05-02-Windows Presentation Foundation (WPF)-LAB.ps1
Add-Type -AssemblyName PresentationCore, PresentationFramework

$Xaml = @"
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" Width="300" Height="250">
<Grid>
 <Button Content="OK" HorizontalAlignment="Left" VerticalAlignment="Top" Width="70" Margin="25,170,0,0"  Name="OKButton" Height="23"/>
 <Button Content="Cancel" HorizontalAlignment="Left" VerticalAlignment="Top" Width="70" Margin="100,170,0,0" Name="CancelButton" Height="23" IsCancel="True"/>
 <Button Content="Disable" HorizontalAlignment="Left" VerticalAlignment="Top" Width="70" Margin="175,170,0,0"  Name="DisableButton" Height="23"/>
 <Label HorizontalAlignment="Left" VerticalAlignment="Top" Content="new password" Margin="10,120,0,0" Name="LPasswd"/>
 <TextBox HorizontalAlignment="Left" VerticalAlignment="Top" Height="20" Width="150" TextWrapping="Wrap" Margin="120,120,0,0" Name="TBPasswd"/>
 <ListBox HorizontalAlignment="Left" BorderBrush="Black" BorderThickness="1" Height="70" VerticalAlignment="Top" Width="260" Margin="10,40,0,0" Name="listBox"  />
 <Label HorizontalAlignment="Left" VerticalAlignment="Top" Content="Please make a selection from the list below:" Margin="10,20,0,0" Name="label"/>
</Grid></Window>
"@

$Window = [Windows.Markup.XamlReader]::Parse($Xaml)

[xml]$xml = $Xaml

#$xml.SelectNodes("//*[@Name]") | ForEach-Object { $_.Name }
$xml.SelectNodes("//*[@Name]") | ForEach-Object { Set-Variable -Name $_.Name -Value $Window.FindName($_.Name) }

$ADUsers = Get-ADUser -Filter * -SearchBase "OU=DEMO,DC=Contoso,DC=com"
$listBox.SelectionMode = 'Multiple'
$listBox.Items.Clear()
foreach ($ADUser in $ADUsers) {
    [void]$listBox.Items.Add("$($ADUser.SamAccountName)")
}

$OKButton.Add_Click( {
        $SelectedUsers = $listBox.SelectedItems
        $pass = $($TBPasswd.text) | ConvertTo-SecureString -AsPlainText -Force
        foreach ($SelectedUser in $SelectedUsers) {
            Write-Host "Reset password: $SelectedUser"
            Set-ADAccountPassword -Identity $SelectedUser -NewPassword  $pass
        }
        $TBPasswd.text = ""
    })

$DisableButton.Add_Click( {
        $SelectedUsers = $listBox.SelectedItems
        foreach ($SelectedUser in $SelectedUsers) {
            Write-Host "Disabled account: $SelectedUser" -ForegroundColor Cyan
            Disable-ADAccount -Identity $SelectedUser
        }
    })

$Window.ShowDialog()
#endregion - 05-02-Windows Presentation Foundation (WPF)-LAB.ps1