﻿
#region - 08-01-Tworzenie i wdrażanie konfiguracji DSC-LAB.ps1
#region - przygotowanie środowiska
Set-Service -ComputerName PSA-SVR1 -Name BITS -StartupType Disabled -PassThru
# jeżeli jest problem z komunikacją to na PSA-SVR1 wykonaj
# Enable-NetFirewallRule -DisplayGroup 'Remote Service Management'
Remove-WindowsFeature -Name 'Print-Server' -IncludeManagementTools -ComputerName PSA-SVR1
#endregion -

#region - weryfikacja środowiska przed DSC
if (((Get-Service -ComputerName PSA-SVR1 -Name BITS).StartType) -eq "Disabled") {
    Write-Host "BITS: `tDisabled" -ForegroundColor Green

} else {
    Write-Host "BITS: `tnie jest 'Disabled'" -ForegroundColor Red
}
if (((Get-WindowsFeature -Name 'Print-Server' -ComputerName PSA-SVR1).InstallState) -eq 'Available') {
    Write-Host "Print-Server: `tAvailable" -ForegroundColor Green
} else {
    Write-Host "Print-Server:: `tchyba jest zainstalowany'" -ForegroundColor Red
}
#endregion -

#region - Configuration
Configuration MyDSCLab {

    Import-DscResource -ModuleName 'PSDesiredStateConfiguration'

    Node PSA-SVR1 {

        WindowsFeature PrintServer {
            Ensure = 'Present'
            Name   = 'Print-Server'
        }

        Service BITS {
            Name        = 'BITS'
            State       = 'Running'
            StartupType = 'Automatic'
        }
    }
}
#endregion -

#region - MOF
MyDSCLab -OutputPath C:\DSCLab -Verbose
#endregion -

#region - SET
Start-DscConfiguration -Path C:\DSCLab -Wait -Verbose -Force
#endregion -

#region - weryfikacja środowiska po DSC
if (((Get-Service -ComputerName PSA-SVR1 -Name BITS).StartType) -eq "Automatic") {
    Write-Host "BITS: `tAutomatic" -ForegroundColor Green

} else {
    Write-Host "BITS: `tnie jest 'Automatic'" -ForegroundColor Red
}

if (((Get-WindowsFeature -Name 'Print-Server' -ComputerName PSA-SVR1).InstallState) -eq 'Installed') {
    Write-Host "Print-Server: `tInstalled" -ForegroundColor Green
} else {
    Write-Host "Print-Server:: `tchyba nie jest zainstalowany'" -ForegroundColor Red
}
#endregion -
#endregion - 08-01-Tworzenie i wdrażanie konfiguracji DSC-LAB.ps1