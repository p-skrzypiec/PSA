﻿
#region - 06-01-Pisanie kontrolerów skryptów-LAB.ps1
Remove-Variable -Name SelectedUsers
Remove-Variable -Name SelectedUser
Remove-Variable -Name choice
$Exit = $false
Do {
    Clear-Host
    Write-Host "S. Select users"
    Write-Host "G. Get users"
    Write-Host "P. Password reset"
    Write-Host "D. Disable users"
    Write-Host "E. Enable users"
    Write-Host "X. Exit"

    $choice = Read-Host "Enter your choice"
    Switch ($choice) {
        'S' {
            $SelectedUsers = Get-ADUser -Filter * -Properties  PasswordLastSet | Select-Object name, PasswordLastSet, Enabled | Out-GridView -OutputMode Multiple
        }
        'G' {
            foreach ($SelectedUser in $SelectedUsers) {
                Write-Host "Reset password: $($SelectedUser.name)"
                Get-ADUser $($SelectedUser.name)
            }
            Read-Host -Prompt "Enter to continue"
        }
        'P' {
            $pass = Read-Host -AsSecureString
            foreach ($SelectedUser in $SelectedUsers) {
                Write-Host "Reset password: $($SelectedUser.name)"
                Set-ADAccountPassword -Identity $($SelectedUser.name) -NewPassword  $pass
            }
            Read-Host -Prompt "Enter to continue"
        }
        'D' {
            foreach ($SelectedUser in $SelectedUsers) {
                Write-Host "Disabled account: $($SelectedUser.name)" -ForegroundColor Cyan
                Get-ADUser $($SelectedUser.name) | Disable-ADAccount -PassThru
            }
            Read-Host -Prompt "Enter to continue"
        }
        'E' {
            foreach ($SelectedUser in $SelectedUsers) {
                Write-Host "Enable account: $($SelectedUser.name)" -ForegroundColor Cyan
                Get-ADUser $($SelectedUser.name) | Enable-ADAccount -PassThru
            }
            Read-Host -Prompt "Enter to continue"
        }
        'X' {
            Write-Host "bye bye" -ForegroundColor Yellow
            $Exit = $true
        }
        default {
            Write-Host "Unknown choice" -ForegroundColor red
            Read-Host -Prompt "Enter to continue"
        }
    }
} Until ($Exit)
#endregion - 06-01-Pisanie kontrolerów skryptów-LAB.ps1